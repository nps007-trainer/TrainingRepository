package com.spring.jdbc.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.spring.jdbc.Model.Student;

public class StudentDaoImpl implements StudentDao {

	private JdbcTemplate jdbcTemplate;
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	public int insertRecord(Student student) {
		
		  //insert 
        String q="insert into student (studentid,studentname,studentaddress) values (?,?,?)";
        int r=this.jdbcTemplate.update(q,student.getStudentId(),student.getStudentName(),student.getStudentAddress());
		return r;
	}
	public int updateRecord(Student student) {
		String q="update student set studentname=? where studentid=?";
		
		int r=this.jdbcTemplate.update(q,student.getStudentName(),student.getStudentId());
		
		return r;
	}

}
