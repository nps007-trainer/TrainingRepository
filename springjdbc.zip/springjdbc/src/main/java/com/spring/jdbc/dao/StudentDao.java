package com.spring.jdbc.dao;

import com.spring.jdbc.Model.Student;

public interface StudentDao {

	public int insertRecord(Student student);
	public int    updateRecord(Student student);
}
