package com.spring.jdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.spring.jdbc.Model.Student;
import com.spring.jdbc.dao.StudentDao;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello Spring JDBC!" );
        
        
        ApplicationContext ac=new ClassPathXmlApplicationContext("com/spring/jdbc/beans.xml");
      // JdbcTemplate template=ac.getBean("jdbcTemplate",JdbcTemplate.class);
        
      // simple take an object of StudentDaoImpl
        
      StudentDao sd=  ac.getBean("sDao",StudentDao.class);
      
      // creating student object
//        Student s=new Student();
//        s.setStudentId(3);
//        s.setStudentName("Harshit");
//        s.setStudentAddress("mno");
//        
//        int result=sd.insertRecord(s);
        
     //   int r=sd.update(q,2,"Madhuri","pqr");
      
      Student s=new Student();
     s.setStudentId(3);
     s.setStudentName("Harshit J");
      int result=sd.updateRecord(s);
        System.out.println(result + " row in set");
        
        
       
       
    }
}
