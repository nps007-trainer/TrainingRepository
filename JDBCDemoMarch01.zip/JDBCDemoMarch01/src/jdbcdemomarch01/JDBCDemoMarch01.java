/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcdemomarch01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class JDBCDemoMarch01 {

    private static Connection con=null;
    private static Statement stmt=null;
    private static PreparedStatement pstmt=null;
    private static String url="jdbc:derby://localhost:1527/InternCogDb;user=cog;password=pass@123";
    
    
    public static void createConnection() throws InstantiationException, ClassNotFoundException, IllegalAccessException, SQLException{
        Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
        con=DriverManager.getConnection(url);
        System.out.println("Connection successful");
        
    }
    
    public static void insertRecord(int id, String name, String skills) throws SQLException{
//     String query="insert into Associates values(" + id + ",'" +name +"','" +skills +"')";
//        stmt=con.createStatement();
//        stmt.execute(query);
//        System.out.println("Record added successfully");

String query="insert into Associates values(?,?,?)";
pstmt=con.prepareStatement(query);
pstmt.setInt(1, id);
pstmt.setString(2, name);
pstmt.setString(3, skills);
int c=pstmt.executeUpdate();
        System.out.println(c +" record added in row set ");

         }
    
    
    public static void updateRecord(String skill, int id) throws SQLException{
        String query="Update associates set associateskills=? where associateid=?";
        pstmt=con.prepareStatement(query);
        pstmt.setString(1, skill);
        pstmt.setInt(2, id);
        int c=pstmt.executeUpdate();
        System.out.println(c +" record added in row set ");
        
    }
    
    public static void deleteRecord(int id) throws SQLException
    {
        String query="delete from associates where associateid=" + id;
        stmt=con.createStatement();
        stmt.execute(query);
        System.out.println("Record deleted successfully");
           }
    
    public static void selectRecords() throws SQLException{
        String query="Select * from associates";
        stmt=con.createStatement();
        ResultSet rs= stmt.executeQuery(query);
        ResultSetMetaData rsmd=rs.getMetaData();
        int count=rsmd.getColumnCount();
        for (int i=1;i<=count;i++){
        System.out.print(rsmd.getColumnLabel(i) + "\t");
           
        }
         System.out.println();
        
         while(rs.next()){
             System.out.print(rs.getInt(1) + "\t\t" + rs.getString(2) + "\t\t" + rs.getString(3));
             System.out.println();
         }
    }
    public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        
       createConnection();
        Scanner sc=new Scanner(System.in);
       System.out.println("Enter Your Id, and  Skills");
     int id=sc.nextInt();
  //    String nm=sc.next();
        String skill=sc.next();
   //   insertRecord(id,nm,skill);
//System.out.println("Enter Your Id");
//       int id=sc.nextInt();
//        deleteRecord(id);

//selectRecords();


        updateRecord(skill, id);

    }
    
}
