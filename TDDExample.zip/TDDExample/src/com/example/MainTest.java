package com.example;

public class MainTest {

	
	
	public static void main(String[] args) {
		System.out.println("Hello Assert");
		
		String uName="NPS";
		String uName1="N P S";
		String uName2="N@PS";
		
		isValidUserName(uName1);
		isValidUserName(uName);
		isValidUserName(uName2);

	}
	
public	static boolean isValidUserName(String name){
		if (name.contains("@") ||  name.contains(" ") || name.contains("/") || name.contains(".") || name.contains("#")){
			return false;
		}
		else{
		
		return true;
		}
	}

}
