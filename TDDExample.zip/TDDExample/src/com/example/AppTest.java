package com.example;

import static org.junit.Assert.*;

import org.junit.Test;

public class AppTest {

	@Test
	public void displayResultWithTrue(){
	
		String userName="NPS";
		String userName1="N P S";
		String userName2="N@PS";
		String userName3="N_PS";
		String userName4="N/PS";
		String userName5="N#PS";
		String userName6="N.PS";
		
		assertTrue(MainTest.isValidUserName(userName));
		assertTrue(MainTest.isValidUserName(userName1));
		assertTrue(MainTest.isValidUserName(userName2));
	//	assertTrue(MainTest.isValidUserName(userName3));
	//	assertTrue(MainTest.isValidUserName(userName4));
	//	assertTrue(MainTest.isValidUserName(userName5));
	//	assertTrue(MainTest.isValidUserName(userName6));
		
		
		
	}
}


			
			