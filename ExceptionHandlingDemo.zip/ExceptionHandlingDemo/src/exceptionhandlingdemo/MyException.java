/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandlingdemo;


/**
 *
 * @author Admin
 */
//userdefined 
public class MyException extends Exception{
    
    int a;
    public MyException(int b)
    {
        a=b;
    }
    
    // business logic 
    
    @Override
    public String toString()
    {
        return "My Exception number is "+a;
    }
}
