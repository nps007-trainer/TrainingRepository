/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandlingdemo;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.*;

public class ExceptionHandlingDemo {

    public static void main(String[] args) {
//        int num1, num2,sum,res;
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter two numbers");
//        num1=num2=0;
//        sum=res=0;
//        
//        
//        try
//        {
//        num1=sc.nextInt();
//        num2=sc.nextInt();
//        sum=num1+num2;
//        res=num1/num2;
//   
//        }
//       
//        catch(ArithmeticException ae)
//        {
//            System.out.println("Cannot divide by zero");
//            System.out.println(ae.getMessage());
//        }
////        catch(InputMismatchException ie)
////        {
////            System.out.println("Please enter correct details");
////        } 
//        // to be handled here thrown by main()
//         catch(Exception e)
//        {
//            System.out.println("Exception handled here");
//        }
//   // not mandatory -- regardless of exception
//      finally
//        {
//            System.out.println("Sum of two numbers = "+sum);
//            System.out.println("Division = "+res);
//        }
//        
        System.out.println("==========Custom Exception==========");
        try{
            throw new MyException(3);
        }
        catch(MyException ex){
            
        }
       
 
//        // java -ea applicationname - cmd 
        int age=19;
        assert age>=18 : "Can Vote";
        System.out.println("the age is "+age);

 
//TestingException obj=new TestingException();
//obj.operate();
    }
    
}
