package com.aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class SimpleAOP {

	public static void main(String[] args) {
		System.out.println("Hello AOP");
		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
Innocent obj=context.getBean(Innocent.class);

obj.show();
	}

}
