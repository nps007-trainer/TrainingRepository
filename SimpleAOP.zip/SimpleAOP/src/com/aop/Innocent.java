package com.aop;

import org.springframework.stereotype.Component;

@Component
public class Innocent {
  // - my advice whenever the show() is called we want log information to be called before this
	public void show(){
		System.out.println("Called from Innocent class");
	}
}
