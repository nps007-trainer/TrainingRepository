package com.aop;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

//aspect 
//Advice -- > what 
// PointCut --> where or when it is to be called
// 		when --> before / after 

@Component
@Aspect
@EnableAspectJAutoProxy
public class Helper {

	@Before("execution(public void show())")
	public void log(){
		System.out.println("Log called from Helper!!!");
	}
}
