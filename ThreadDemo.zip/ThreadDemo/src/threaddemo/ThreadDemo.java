
package threaddemo;


public class ThreadDemo extends Thread {

    public static void main(String[] args) throws InterruptedException {
      // instance of a thread class
      ThreadDemo td=new ThreadDemo();
        System.out.println("Main begins here!!!!!");
        td.start();
        System.out.println("Main ends here!!!!!");
        System.out.println("============ calling runnable ==========");
        
        RunnableClass rc=new RunnableClass();
        Thread t1=new Thread(rc);
        t1.start();
        
        
        // implementing runnable as anoymous class
        
        Thread t2=new Thread(new Runnable() {
          @Override
          public void run() {
              System.out.println("Calling runnable anonymously");
          }
      });
        
        t2.start();
        
        System.out.println("using lambda expression");
        
        Thread t3=new Thread(()->System.out.println("Calling runnable as lambda"));
        t3.start();
        
        // another way
        
        new Thread(()->System.out.println("another way of runnable using lambda")).start();
        
        System.out.println("========== concurrency problem=============");
        
        ConcurrencyClass obj=new ConcurrencyClass();
      obj.start();
        //wait for thread to finish
        while(obj.isAlive()){
            System.out.println("Executing...........");
        }
        //update the salary and print the updated value
        System.out.println(ConcurrencyClass.salary);
        obj.increment();
        System.out.println(ConcurrencyClass.salary);
        System.out.println("================== Join Example=================");
        
        JoinClass j1=new JoinClass();
        JoinClass j2=new JoinClass();
        JoinClass j3=new JoinClass();
        //JoinClass j4=new JoinClass();
        
        j1.start();
        j1.join();
        j2.start();
        j3.start();
    }
    
    public void run(){
        System.out.println("Calling Thread ");
    }
    
}
