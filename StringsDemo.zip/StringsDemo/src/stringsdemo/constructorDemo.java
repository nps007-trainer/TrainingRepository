/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringsdemo;

/* Constructor is a special method same as class name,used to 
initialize the members of a class

Constructor does not have any return type not even void */ 
public class constructorDemo {
    
    int myVal;
    
    public  constructorDemo(int x)        //constructor 
    {
        myVal=x;
    }
    
    public void display()
    {
        System.out.println(myVal);
    }
}
