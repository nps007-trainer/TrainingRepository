/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringsdemo;

/**
 *
 * @author Admin
 */
public class MangoVarieties {
   
    enum Mango{     // enum of Mango type 
    Carrie(150), Fairchild(100),Haden(200);
    private int Price;      // private member of enum
    
    Mango(int p)        //constructor
    {
        Price=p;
    }
    
    int getprice()      // method that will return Price value
    {
        return Price;
    }
    }
}
