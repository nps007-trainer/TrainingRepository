/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringsdemo;

/**
 *
 * @author Admin
 */
enum Days
{
    sun,mon,tue,wed,thu,fri,sat;
}
public class EnumDemo {
    
    Days d;
    public void display()
    {
        Days x=d.sun;
        Days y=d.fri;
        int x1=d.sun.ordinal();
        System.out.println(x1);
    }
}
