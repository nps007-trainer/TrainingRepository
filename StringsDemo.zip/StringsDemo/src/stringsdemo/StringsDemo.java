
package stringsdemo;

import java.util.Scanner;
import stringsdemo.MangoVarieties.*;

public class StringsDemo {

    
    public static void main(String[] args) {
     /*  String str1;
      
       char ch;
       char v; 
       Scanner sc=new Scanner(System.in);
        System.out.println("Enter your name");
        str1=sc.next();
        System.out.println("Enter your gender(m/f)");
        ch=sc.next().charAt(0);
        System.out.println("hello "+str1);
        System.out.println("Gender "+ch);
        
        System.out.println("Enter any alphabet");
        v=sc.next().charAt(0);
        
        if(v=='A')
        {
            System.out.println("Vowel");
        }
        else
        {
            System.out.println("Consonant");
    }
        System.out.println("====== String functions========");
        int l= str1.length();
        System.out.println("The length of string is "+l);
        
        boolean b=str1.contains("n");
        System.out.println(b);
        
        String login;           //niit  
        String password;        //pass@123
        
        System.out.println("Enter Login name and Password");
        login=sc.next();
        password=sc.next();
        
        if(login.equalsIgnoreCase("niit") && password.equals("pass@123"))
        {
            System.out.println("Login Successful");
        }
        else
        {
            System.out.println("Invalid credentials");
        }
      
        
        System.out.println("==== Calling array of unknown size===");
        
        Array2 obj=new Array2();
        obj.display(); */
        
        System.out.println("======== Calling Enum======");
        EnumDemo d=new EnumDemo();
        d.display();
        
        
        //constructor gets invoked as we create object of a class
        
        constructorDemo cd=new constructorDemo(45);
        cd.display();
        
        System.out.println("=======Mango Varieties ========");
       
      for(Mango m : Mango.values())
      {
          System.out.println(m + " Price = "+ m.getprice());
          
      }
        
       
       
        
    }
    
}
