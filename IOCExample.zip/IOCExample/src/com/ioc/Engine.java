package com.ioc;

public interface Engine {
void start();
}
