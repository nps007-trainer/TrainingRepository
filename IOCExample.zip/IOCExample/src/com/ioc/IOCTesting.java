package com.ioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

class Keys
{
	public void run(Engine key)		// little loosely coupled
	{
		key.start();
	}							
	
	
	
}


public class IOCTesting {

	public static void main(String[] args) {		// inverted the control
	System.out.println("Hello IOC and DI");
	
	ApplicationContext ac=new ClassPathXmlApplicationContext("beans.xml");
	
	Engine key1=(Engine) ac.getBean("engine1");
	
	new Keys().run(key1);
	
	

}
	}

