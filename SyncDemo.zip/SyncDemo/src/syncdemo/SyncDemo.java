/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package syncdemo;

import java.util.logging.Level;
import java.util.logging.Logger;

class Sender
{
    public  void Send(String msg)
    {
        try {
            System.out.println("Sending \t"+msg);
            Thread.sleep(2000);
            System.out.println(msg +"sent");
        } catch (InterruptedException ex) {
            Logger.getLogger(Sender.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

class ThreadedSend extends Thread
{
    private String msg;
    //has a sender object
    Sender sender;
    ThreadedSend(String m, Sender s)
    {
        msg=m;
        sender=s;
    }
    
    public void run()
    {
        //only one thread to send a message at a time-- Synchronized block
        synchronized(sender)
        {
            sender.Send(msg);
        }
        
      
    }
}
public class SyncDemo {

    public static void main(String[] args) throws InterruptedException {
       Sender snd=new Sender();
       ThreadedSend t1=new ThreadedSend("HI", snd);
       ThreadedSend t2=new ThreadedSend("Hello ",snd);
       
       t1.start();
    //    t1.join();
       t2.start();
       
     
    }
    
}
