/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ICHDApp;

/**
 *
 * @author admin
 */
public class Account {
    
    private String accountNumber;
    private String accountCreationDate;
    private double balance;
    private String accountType;
    
    public Account(String accountNumber, String accountType, String accountCreationDate, double balance){

    this.accountNumber=accountNumber;
    this.accountCreationDate=accountCreationDate;
    this.balance=balance;
    this.accountType=accountType;
}

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountCreationDate() {
        return accountCreationDate;
    }

    public void setAccountCreationDate(String accountCreationDate) {
        this.accountCreationDate = accountCreationDate;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountTYpe(String accountTYpe) {
        this.accountType = accountTYpe;
    }
    
    public Account(){
        
    }
    
}
 
