/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.niit;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Admin
 */
@Entity
@Table(name = "REGISTRATION")
@NamedQueries({
    @NamedQuery(name = "RegistrationEntity.findAll", query = "SELECT r FROM RegistrationEntity r")
    , @NamedQuery(name = "RegistrationEntity.findByUserid", query = "SELECT r FROM RegistrationEntity r WHERE r.userid = :userid")
    , @NamedQuery(name = "RegistrationEntity.findByUsername", query = "SELECT r FROM RegistrationEntity r WHERE r.username = :username")
    , @NamedQuery(name = "RegistrationEntity.findByPassword1", query = "SELECT r FROM RegistrationEntity r WHERE r.password1 = :password1")
    , @NamedQuery(name = "RegistrationEntity.findByPassword2", query = "SELECT r FROM RegistrationEntity r WHERE r.password2 = :password2")})
public class RegistrationEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "USERID")
    private Integer userid;
    @Size(max = 20)
    @Column(name = "USERNAME")
    private String username;
    @Size(max = 20)
    @Column(name = "PASSWORD1")
    private String password1;
    @Size(max = 20)
    @Column(name = "PASSWORD2")
    private String password2;

    public RegistrationEntity() {
    }

    public RegistrationEntity(Integer userid) {
        this.userid = userid;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword1() {
        return password1;
    }

    public void setPassword1(String password1) {
        this.password1 = password1;
    }

    public String getPassword2() {
        return password2;
    }

    public void setPassword2(String password2) {
        this.password2 = password2;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (userid != null ? userid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof RegistrationEntity)) {
            return false;
        }
        RegistrationEntity other = (RegistrationEntity) object;
        if ((this.userid == null && other.userid != null) || (this.userid != null && !this.userid.equals(other.userid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.niit.RegistrationEntity[ userid=" + userid + " ]";
    }
    
}
