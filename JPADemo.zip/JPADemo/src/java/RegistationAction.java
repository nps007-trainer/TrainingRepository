/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import com.niit.RegistrationEntity;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 *
 * @author Admin
 */
public class RegistationAction extends org.apache.struts.action.Action {

    /* forward name="success" path="" */
    private static final String SUCCESS = "success";
private static final String ERROR = "error";
    /**
     * This is the action called from the Struts framework.
     *
     * @param mapping The ActionMapping used to select this instance.
     * @param form The optional ActionForm bean for this request.
     * @param request The HTTP Request we are processing.
     * @param response The HTTP Response we are processing.
     * @throws java.lang.Exception
     * @return
     */
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        RegistrationForm rf=(RegistrationForm) form;
        int id=rf.getUserid();
        String uname=rf.getUsername();
        String pass1=rf.getPassword1();
        String pass2=rf.getPassword2();
        String msg;
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAPU");
        EntityManager em=emf.createEntityManager();
        EntityTransaction et=em.getTransaction();
        et.begin();
        Query query=em.createNativeQuery("Select Username from Registration where userid = "+id);
        List idlist=query.getResultList();
        if(idlist.size()==1)
        {
            msg="user id already exists";
            request.setAttribute("errmsg", msg);
            return mapping.findForward(ERROR);
        } 
         //when id entered is unqiue
        else if(!pass1.equals(pass2) || pass1=="")
        {
           // password validity and nullability
            msg="password does not match or not entered";
            request.setAttribute("errmsg", msg);
            return mapping.findForward(ERROR);
        }
        else
        {
            // entity classes from database
        RegistrationEntity re=new  RegistrationEntity();
        re.setUserid(id);
        re.setUsername(uname);
        re.setPassword1(pass1);
        re.setPassword2(pass2);
        // permenantely store the data in our backend datasource
        em.persist(re);
        
        //committing transaction successfully
        et.commit();
        em.close();
        emf.close();
        msg=uname;
        request.setAttribute("NewUser", msg);
               
        return mapping.findForward(SUCCESS);
        }
    }
}
